package com.example.autoreminder

import android.app.*
import android.os.Bundle
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private lateinit var box: LinearLayout
    private val prefs by lazy { getSharedPreferences("cars", MODE_PRIVATE) }
    private val df = SimpleDateFormat("dd.MM.yyyy", Locale("bg"))
    override fun onCreate(b: Bundle?) { super.onCreate(b); if (android.os.Build.VERSION.SDK_INT>=33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"),5); showMain() }
    private fun showMain(){
        box=LinearLayout(this); box.orientation=LinearLayout.VERTICAL; box.setPadding(24,24,24,24)
        val title=TextView(this); title.text="🚗 Auto Reminder"; title.textSize=26f; title.setTextColor(Color.BLACK); box.addView(title)
        val add=Button(this); add.text="＋ Добави автомобил"; add.setOnClickListener{addCar()}; box.addView(add)
        val n=prefs.getInt("count",0)
        if(n==0){ val t=TextView(this); t.text="\nНяма добавени автомобили.\nДобави автомобил и създай напомняния за ГО, ГТП, винетка, масло и други обслужвания."; t.textSize=17f; box.addView(t) }
        for(i in 0 until n) carCard(i)
        setContentView(ScrollView(this).apply{addView(box)})
    }
    private fun carCard(i:Int){
        val name=prefs.getString("name$i","Автомобил")!!; val km=prefs.getLong("km$i",0)
        val card=LinearLayout(this); card.orientation=LinearLayout.VERTICAL; card.setPadding(0,28,0,16)
        val t=TextView(this); t.text="🚘 $name\nТекущ километраж: $km км"; t.textSize=19f; card.addView(t)
        val b=Button(this); b.text="Напомняния"; b.setOnClickListener{showReminders(i)}; card.addView(b)
        val edit=Button(this); edit.text="Промени автомобил"; edit.setOnClickListener{editCar(i)}; card.addView(edit); box.addView(card)
    }
    private fun addCar(){ editCar(-1) }
    private fun editCar(i:Int){
        val l=LinearLayout(this); l.orientation=LinearLayout.VERTICAL; l.setPadding(40,20,40,10)
        val name=EditText(this); name.hint="Име/модел"; if(i>=0)name.setText(prefs.getString("name$i","")); l.addView(name)
        val km=EditText(this); km.hint="Текущ километраж"; km.inputType=2; if(i>=0)km.setText(prefs.getLong("km$i",0).toString()); l.addView(km)
        AlertDialog.Builder(this).setTitle(if(i<0)"Нов автомобил" else "Автомобил").setView(l).setPositiveButton("Запази"){_,_-> val idx=if(i<0)prefs.getInt("count",0) else i; prefs.edit().putString("name$idx",name.text.toString().ifBlank{"Автомобил"}).putLong("km$idx",km.text.toString().toLongOrNull()?:0).putInt("count",maxOf(prefs.getInt("count",0),idx+1)).apply(); showMain() }.setNegativeButton("Отказ",null).show()
    }
    private fun showReminders(i:Int){
        val types=arrayOf("ГО","ГТП","Винетка","Масло","Гуми","Друг сервиз")
        AlertDialog.Builder(this).setTitle(prefs.getString("name$i","Автомобил")).setItems(types){_,which->addReminder(i,types[which])}.setNegativeButton("Затвори",null).show()
    }
    private fun addReminder(i:Int,type:String){
        val l=LinearLayout(this); l.orientation=LinearLayout.VERTICAL; l.setPadding(30,10,30,10)
        val date=EditText(this); date.hint="Дата (дд.мм.гггг)"; l.addView(date)
        val target=EditText(this); target.hint="Целеви километраж (по желание)"; target.inputType=2; l.addView(target)
        val interval=EditText(this); interval.hint="Повтаряй на всеки дни (по желание)"; interval.inputType=2; l.addView(interval)
        AlertDialog.Builder(this).setTitle("Напомняне: $type").setView(l).setPositiveButton("Запази"){_,_->
            val key="r${System.currentTimeMillis()}"; prefs.edit().putString("$key.car",i.toString()).putString("$key.type",type).putString("$key.date",date.text.toString()).putLong("$key.km",target.text.toString().toLongOrNull()?:0).putInt("$key.repeat",interval.text.toString().toIntOrNull()?:0).apply(); Toast.makeText(this,"Запазено. Известия: 30/14/7/3/1 дни и в деня.",Toast.LENGTH_LONG).show()
        }.setNegativeButton("Отказ",null).show()
    }
}
